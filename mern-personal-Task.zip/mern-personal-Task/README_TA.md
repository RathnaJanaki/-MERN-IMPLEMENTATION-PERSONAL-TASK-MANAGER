# Personal Task Manager – MERN Stack

இந்த project-ல் Register, Login, Task Create, View, Edit, Delete, Status update மற்றும் Priority வசதிகள் உள்ளன.

## தேவையானவை
- Node.js (LTS) மற்றும் npm
- MongoDB Community Server அல்லது MongoDB Atlas
- VS Code

## 1. MongoDB அமைத்தல்
Local MongoDB பயன்படுத்தினால் MongoDB service இயங்க வேண்டும். Atlas பயன்படுத்தினால் cluster connection string-ஐ எடுத்துக்கொள்ளவும்.

## 2. Backend தொடங்குதல்
Terminal 1:
```bash
cd server
npm install
```
`server/.env.example` கோப்பை copy செய்து `.env` என்று பெயர் மாற்றவும். அதில் `MONGODB_URI` மற்றும் நீளமான `JWT_SECRET` அமைக்கவும்.
```bash
npm run dev
```
Backend: http://localhost:5000

## 3. Frontend தொடங்குதல்
Terminal 2:
```bash
cd client
npm install
```
`client/.env.example`-ஐ copy செய்து `.env` என பெயர் மாற்றவும்.
```env
VITE_API_URL=http://localhost:5000/api
```
பிறகு:
```bash
npm run dev
```
Browser-ல் Vite காட்டும் முகவரியை திறக்கவும்; பொதுவாக http://localhost:5173

## 4. பயன்படுத்துவது
1. Register பக்கத்தில் பெயர், Email, குறைந்தது 6 எழுத்துகள் கொண்ட Password கொடுக்கவும்.
2. Dashboard-ல் Task சேர்க்கவும்.
3. Edit மூலம் மாற்றவும்; Delete மூலம் நீக்கவும்.
4. Dropdown மூலம் Pending / In Progress / Completed நிலையை மாற்றலாம்.
5. Filter மூலம் தேவையான Task-களை மட்டும் பார்க்கலாம்.

## API Endpoints
| Method | Endpoint | விளக்கம் |
|---|---|---|
| POST | /api/auth/register | புதிய கணக்கு |
| POST | /api/auth/login | Login |
| GET | /api/tasks | Login செய்த பயனரின் Tasks |
| POST | /api/tasks | Task சேர்க்க |
| PUT | /api/tasks/:id | Task மாற்ற |
| DELETE | /api/tasks/:id | Task நீக்க |

Task endpoints அனைத்திற்கும் `Authorization: Bearer <token>` தேவை.

## முக்கிய பாதுகாப்பு
- Password bcrypt மூலம் hash செய்யப்படுகிறது.
- JWT மூலம் Login authentication.
- ஒவ்வொரு Task-மும் அதன் உரிமையாளருடன் இணைக்கப்படுகிறது; மற்ற பயனரின் Task-ஐ பார்க்க/மாற்ற முடியாது.
- `.env`-ஐ GitHub-ல் upload செய்ய வேண்டாம். `.env.example` மட்டும் upload செய்யவும்.

## GitHub-ல் upload
Project root-ல்:
```bash
git init
git add .
git commit -m "Personal Task Manager MERN project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
