import React from "react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios.js";
import { useAuth } from "../context/AuthContext.jsx";
import TaskForm from "../components/TaskForm.jsx";
import TaskItem from "../components/TaskItem.jsx";
export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tasks, setTasks] = useState([]);
  const [editingTask, setEditingTask] = useState(null);
  const [filter, setFilter] = useState("All");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const loadTasks = useCallback(async () => {
    try {
      const { data } = await api.get("/tasks");
      setTasks(data); setError("");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load tasks.");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadTasks(); }, [loadTasks]);

  const saveTask = async (form) => {
    try {
      if (editingTask) {
        const { data } = await api.put(`/tasks/${editingTask._id}`, form);
        setTasks((old) => old.map((t) => t._id === data._id ? data : t));
        setEditingTask(null);
      } else {
        const { data } = await api.post("/tasks", form);
        setTasks((old) => [data, ...old]);
      }
    } catch (err) {
      alert(err.response?.data?.message || "Failed to save task.");
      throw err;
    }
  };

  const deleteTask = async (id) => {
    if (!window.confirm("Are you sure you want to delete this task?")) return;
    try {
      await api.delete(`/tasks/${id}`);
      setTasks((old) => old.filter((t) => t._id !== id));
    } catch (err) { alert(err.response?.data?.message || "Failed to delete task."); }
  };

  const changeStatus = async (task, status) => {
    try {
      const { data } = await api.put(`/tasks/${task._id}`, { status });
      setTasks((old) => old.map((t) => t._id === data._id ? data : t));
    } catch (err) { alert(err.response?.data?.message || "Failed to update task status."); }
  };

  const counts = useMemo(() => ({
    total: tasks.length,
    pending: tasks.filter((t) => t.status === "Pending").length,
    progress: tasks.filter((t) => t.status === "In Progress").length,
    completed: tasks.filter((t) => t.status === "Completed").length
  }), [tasks]);

  const visibleTasks = tasks.filter((t) => filter === "All" || t.status === filter);

  const signOut = () => { logout(); navigate("/login"); };

  return (
    <main className="dashboard">
      <header className="topbar">
        <div><div className="brand-small">✓ TASK MANAGER</div><h1>Welcome, {user?.name}!</h1><p>Plan your daily tasks and get things done.</p></div>
        <button className="secondary" onClick={signOut}>Logout</button>
      </header>

      {error && <div className="error">{error} <button onClick={loadTasks}>Try Again</button></div>}

      <section className="stats">
        <div className="stat"><span>Total Tasks</span><strong>{counts.total}</strong></div>
        <div className="stat"><span>Pending</span><strong>{counts.pending}</strong></div>
        <div className="stat"><span>In Progress</span><strong>{counts.progress}</strong></div>
        <div className="stat"><span>Completed</span><strong>{counts.completed}</strong></div>
      </section>

      <section className="main-grid">
        <TaskForm editingTask={editingTask} onSave={saveTask} onCancel={() => setEditingTask(null)} />
        <div className="task-list-section">
          <div className="list-heading"><div><h2>My Tasks</h2><p>Your daily tasks</p></div>
            <select value={filter} onChange={(e) => setFilter(e.target.value)}>
              <option>All</option><option>Pending</option><option>In Progress</option><option>Completed</option>
            </select>
          </div>
          {loading ? <p className="empty">Loading...</p> : visibleTasks.length === 0 ?
            <div className="empty">No tasks found. Add a new task to get started.</div> :
            <div className="tasks">{visibleTasks.map((task) =>
              <TaskItem key={task._id} task={task} onEdit={setEditingTask} onDelete={deleteTask} onStatus={changeStatus} />
            )}</div>}
        </div>
      </section>
      <footer>Personal Task Manager · MERN Stack</footer>
    </main>
  );
}
