import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function AuthPage({ mode }) {
  const isRegister = mode === "register";
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const { login, register } = useAuth();
  const navigate = useNavigate();

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = async (e) => {
    e.preventDefault(); setError(""); setBusy(true);
    try {
      if (isRegister) await register(form);
      else await login({ email: form.email, password: form.password });
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to authenticate. Please check the backend.");
    } finally { setBusy(false); }
  };

  return (
    <main className="auth-wrap">
      <form className="auth-card" onSubmit={submit}>
        <div className="brand-mark">✓</div>
        <h1>Personal Task Manager</h1>
        <p>{isRegister ? "Create a new account" : "Sign in to your account"}</p>
        {error && <div className="error">{error}</div>}
        {isRegister && <label>Name<input name="name" value={form.name} onChange={change} required /></label>}
        <label>Email<input type="email" name="email" value={form.email} onChange={change} required /></label>
        <label>Password<input type="password" name="password" value={form.password} onChange={change} minLength="6" required /></label>
        <button className="primary full" disabled={busy}>{busy ? "Please wait..." : isRegister ? "Register" : "Login"}</button>
        <p className="switch">{isRegister ? "Already have an account? " : "Don't have an account? "}
          <Link to={isRegister ? "/login" : "/register"}>{isRegister ? "Login" : "Register"}</Link>
        </p>
      </form>
    </main>
  );
}
