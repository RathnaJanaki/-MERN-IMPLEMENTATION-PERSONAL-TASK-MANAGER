import React, { createContext, useContext, useState } from "react";
import api from "../api/axios.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(localStorage.getItem("task_user")) || null; }
    catch { return null; }
  });

  const saveSession = (data) => {
    localStorage.setItem("task_token", data.token);
    localStorage.setItem("task_user", JSON.stringify(data.user));
    setUser(data.user);
  };

  const login = async (form) => {
    const { data } = await api.post("/auth/login", form);
    saveSession(data);
  };

  const register = async (form) => {
    const { data } = await api.post("/auth/register", form);
    saveSession(data);
  };

  const logout = () => {
    localStorage.removeItem("task_token");
    localStorage.removeItem("task_user");
    setUser(null);
  };

  return <AuthContext.Provider value={{ user, login, register, logout }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
