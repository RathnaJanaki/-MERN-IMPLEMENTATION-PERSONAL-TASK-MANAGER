
import React from "react";

export default function TaskItem({
  task,
  onEdit,
  onDelete,
  onToggle
}) {
  return (
    <div className="task-card">

      <div className="task-details">

        <h3>{task.title}</h3>

        <p>
          {task.description || "No description"}
        </p>

        <div className="task-info">

          <span>
            Priority: {task.priority}
          </span>

          <span>
            Status: {task.status}
          </span>

          <span>
            Due Date:{" "}
            {task.dueDate
              ? new Date(task.dueDate).toLocaleDateString()
              : "No due date"}
          </span>

        </div>

      </div>

      <div className="task-actions">

        <button
          type="button"
          onClick={() => onToggle(task)}
        >
          {task.status === "Completed"
            ? "Mark Pending"
            : "Complete"}
        </button>

        <button
          type="button"
          onClick={() => onEdit(task)}
        >
          Edit
        </button>

        <button
          type="button"
          onClick={() => onDelete(task._id)}
        >
          Delete
        </button>

      </div>

    </div>
  );
}
