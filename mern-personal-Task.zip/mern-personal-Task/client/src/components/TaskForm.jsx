import React, { useEffect, useState } from "react";

const empty = { title: "", description: "", dueDate: "", priority: "Medium", status: "Pending" };

export default function TaskForm({ editingTask, onSave, onCancel }) {
  const [form, setForm] = useState(empty);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (editingTask) {
      setForm({
        title: editingTask.title || "",
        description: editingTask.description || "",
        dueDate: editingTask.dueDate ? editingTask.dueDate.slice(0, 10) : "",
        priority: editingTask.priority || "Medium",
        status: editingTask.status || "Pending"
      });
    } else setForm(empty);
  }, [editingTask]);

  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) return alert("Task title is required.");
    setBusy(true);
    try { await onSave({ ...form, dueDate: form.dueDate || null }); setForm(empty); }
    finally { setBusy(false); }
  };

  return (
    <form className="task-form" onSubmit={submit}>
      <h2>{editingTask ? "Task Edit" : "Add New Task"}</h2>
      <label>Task Title *
        <input name="title" value={form.title} onChange={change} placeholder="e.g., Complete assignment" maxLength="120" required />
      </label>
      <label>Description
        <textarea name="description" value={form.description} onChange={change} rows="3" placeholder="Task description..." />
      </label>
      <div className="form-grid">
        <label>Due Date
          <input type="date" name="dueDate" value={form.dueDate} onChange={change} />
        </label>
        <label>Priority
          <select name="priority" value={form.priority} onChange={change}>
            <option>Low</option><option>Medium</option><option>High</option>
          </select>
        </label>
        <label>Status
          <select name="status" value={form.status} onChange={change}>
            <option>Pending</option><option>In Progress</option><option>Completed</option>
          </select>
        </label>
      </div>
      <div className="actions">
        <button disabled={busy} className="primary">{busy ? "Saving..." : "Save"}</button>
        {editingTask && <button type="button" className="secondary" onClick={onCancel}>Cancel</button>}
      </div>
    </form>
  );
}
