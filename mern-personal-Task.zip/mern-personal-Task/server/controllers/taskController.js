import mongoose from "mongoose";
import Task from "../models/Task.js";

export async function getTasks(req, res) {
  try {
    const tasks = await Task.find({ user: req.user._id }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch tasks.", error: error.message });
  }
}

export async function createTask(req, res) {
  try {
    const { title, description, dueDate, priority, status } = req.body;
    if (!title?.trim()) return res.status(400).json({ message: "Task title is required." });
    const task = await Task.create({
      user: req.user._id,
      title: title.trim(),
      description: description || "",
      dueDate: dueDate || null,
      priority: priority || "Medium",
      status: status || "Pending"
    });
    res.status(201).json(task);
  } catch (error) {
    res.status(400).json({ message: "Failed to create task.", error: error.message });
  }
}

export async function updateTask(req, res) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Task ID is invalid." });
    const allowed = ["title", "description", "dueDate", "priority", "status"];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = req.body[key];
    if (updates.title !== undefined && !updates.title.trim()) {
      return res.status(400).json({ message: "Task title is required." });
    }
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      updates,
      { new: true, runValidators: true }
    );
    if (!task) return res.status(404).json({ message: "Task not found." });
    res.json(task);
  } catch (error) {
    res.status(400).json({ message: "Failed to update task.", error: error.message });
  }
}

export async function deleteTask(req, res) {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: "Task ID is invalid." });
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ message: "Task not found." });
    res.json({ message: "Task deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete task.", error: error.message });
  }
}
